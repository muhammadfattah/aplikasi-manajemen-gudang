<?php

return [
    'name' => 'Outlet'
];
