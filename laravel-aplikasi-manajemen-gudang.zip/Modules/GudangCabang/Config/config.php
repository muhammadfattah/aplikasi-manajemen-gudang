<?php

return [
    'name' => 'GudangCabang'
];
