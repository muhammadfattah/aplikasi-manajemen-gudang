<?php

return [
    'name' => 'GudangPusat'
];
